package Trabajo;
import java.io.File;



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.management.RuntimeErrorException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class FiltrarXML {
	static int kcalPedidas;
	private static int gradoPedido;
	private static List<String> nombreList;
	private static List<String> ingredientesList;
	private static List<String> elementosList;
	private static List<String> cantidadesList;
	private static List<String> medidasList;
	
	static Document document;
	static Element raiz;
	static Element itemNode;
	private static Node keyNode;
	private static Node valueNode;
	
	static boolean flag=true;
	
	public static void main(String[] args){
		 try {
				ejecutarPrograma();
				
				} catch (Exception e) {
			    	System.out.println("No se ha podido abrir.");
			    }
			}
	 
	private static void ejecutarPrograma() {
		try {
			flag=true;
			File fXmlFile = new File("Tarea1/Recetas.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			
			pedirDatos();
			filtrarCalorias(doc);
			if(flag)
				generarXML("recetas");
			
		} catch (Exception e) {
			System.out.println("Ha ocurrido un error.");
			return;
		}
	}

	private static void filtrarCalorias(Document doc) throws ParserConfigurationException {
		nombreList = new ArrayList<String>();
		ingredientesList = new ArrayList<String>();
		elementosList = new ArrayList<String>();
		cantidadesList = new ArrayList<String>();
		medidasList = new ArrayList<String>();
		crearDocumento("recetas");
		NodeList recetas = doc.getElementsByTagName("receta");
		for (int temp = 0; temp < recetas.getLength(); temp++) {
			Node nodoReceta = recetas.item(temp);
			if (nodoReceta.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nodoReceta;
				NodeList calorias = eElement.getElementsByTagName("calorias");
				NodeList  dificultad= eElement.getElementsByTagName("dificultad");
				for (int i = 0; i < calorias.getLength(); i++) {
					Node kcal = calorias.item(i);
					Node grado = dificultad.item(i);
					if (kcal.getNodeType() == Node.ELEMENT_NODE && grado.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement2 = (Element) kcal;
						Element eElement3 = (Element) grado;
						// Guardamos las calorias para luego imprimirlas
						int caloriasPlato = Integer.parseInt(eElement2.getAttribute("kcal").toString());
						int gradoPlato = Integer.parseInt(eElement3.getAttribute("grado").toString());
						if (caloriasPlato <= kcalPedidas && gradoPlato==gradoPedido) {
							a�adirNombre(eElement.getElementsByTagName("nombre").item(i).getTextContent(), eElement2.getAttribute("kcal").toString());
							nombreList.add(eElement.getElementsByTagName("nombre").item(i).getTextContent());
							a�adirIngredientes(eElement);
							a�adirElementos(eElement);
							pasarXML("recetas",nombreList, ingredientesList);
							ingredientesList = new ArrayList<String>();
							elementosList = new ArrayList<String>();
							cantidadesList = new ArrayList<String>();
							medidasList = new ArrayList<String>();
							
						}

					}
				}

			}
		}

	}


	private static void a�adirIngredientes(Element eElement) {
		NodeList ingredientes = eElement.getElementsByTagName("ingrediente");
		for (int j = 0; j < ingredientes.getLength(); j++) {
			Node ingrediente = ingredientes.item(j);
			if (ingrediente.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement4 = (Element) ingrediente;
				String nombre = eElement4.getAttribute("nombre");
				ingredientesList.add(nombre);
				cantidadesList.add(eElement4.getAttribute("cantidad"));
				medidasList.add(eElement4.getAttribute("medida"));
			}
		}
		
	}
	
	private static void a�adirElementos(Element eElement) {
		NodeList elementos = eElement.getElementsByTagName("elemento");
		for (int j = 0; j < elementos.getLength(); j++) {
			Node elemento = elementos.item(j);
			if (elemento.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement5 = (Element) elemento;
				String nombre = eElement5.getAttribute("nombre");
				elementosList.add(nombre);
			}
		}
		
	}

	@SuppressWarnings("resource")
	private static void pedirDatos() {
		try {
			System.out.println("Por favor introduzca la cantidad m�xima de calorias: ");
			kcalPedidas = -1;
			Scanner entradaEscaner = new Scanner(System.in);
			kcalPedidas = Integer.parseInt(entradaEscaner.nextLine());
			System.out.println("Por favor introduzca grado de dificultad (1,2,3) siendo 1 grado f�cil: ");
			gradoPedido = -1;
			gradoPedido = Integer.parseInt(entradaEscaner.nextLine());
			if(gradoPedido<=0 || gradoPedido>3 || kcalPedidas<0)
				throw new RuntimeErrorException(null);
//			System.out.println(kcalPedidas);
//			System.out.println(grado);
		} catch (Exception e) {
			System.out.println("Formato de Kcal o grado incorrecto.");
			flag=false;
			return;
		}
	}
	
	
	
	private static void crearDocumento(String nombre) throws ParserConfigurationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        DOMImplementation implementation = builder.getDOMImplementation();
        document = implementation.createDocument(null, nombre, null);
        document.setXmlVersion("1.0");
        raiz = document.getDocumentElement();
       
	}
	
	private static void a�adirNombre(String nombreReceta,String caloriasReceta) {
		itemNode = document.createElement("receta"); 
        keyNode = document.createElement("nombre"); 
        Text nodeKeyValue = document.createTextNode(nombreReceta);
        keyNode.appendChild(nodeKeyValue);      
        valueNode = document.createElement("calorias"); 
        Text nodeValueValue = document.createTextNode(caloriasReceta);                
        valueNode.appendChild(nodeValueValue);
	}
	
	
	private static void pasarXML(String nombre,List<String> nombreList2, List<String> ingredientesList) throws ParserConfigurationException {
		if(ingredientesList.isEmpty() || nombreList2.isEmpty() ){
            System.out.println("No hay recetas que cumplan los requisitos.");
            return;
        }else{

                
                Element ingredientesNode = document.createElement("ingredientes");
                for(int j=0; j<ingredientesList.size(); j++) {
                Element ingredienteNode = document.createElement("ingrediente"); 
                Text ingredienteValor = document.createTextNode(String.valueOf(ingredientesList.get(j)));
                Text cantidadValor = document.createTextNode(String.valueOf(cantidadesList.get(j)));
                Text medidaValor = document.createTextNode(String.valueOf(medidasList.get(j)));
                ingredienteNode.setAttribute("nombre",String.valueOf(ingredienteValor));
                ingredienteNode.setAttribute("cantidad",String.valueOf(cantidadValor));
                ingredienteNode.setAttribute("medida",String.valueOf(medidaValor));
                ingredientesNode.appendChild(ingredienteNode);
                }
                
                Element elementosNode = document.createElement("elementos");
                for(int f=0; f<elementosList.size(); f++) {
                Element elementoNode = document.createElement("elemento"); 
                Text elementoValor = document.createTextNode(String.valueOf(elementosList.get(f)));    
                elementoNode.setAttribute("nombre",String.valueOf(elementoValor));
                elementosNode.appendChild(elementoNode);
                }
                
                
                itemNode.appendChild(keyNode);
                itemNode.appendChild(valueNode);
                itemNode.appendChild(ingredientesNode);
                itemNode.appendChild(elementosNode);
                raiz.appendChild(itemNode); 
            }                
        
    }
	
	
	
	private static void generarXML(String nombre) throws TransformerFactoryConfigurationError, TransformerException {
		//Generamos XML
        Source source = new DOMSource(document);
        //Indicamos donde lo queremos almacenar
        Result result = new StreamResult(new java.io.File(nombre+".xml")); //nombre del archivo
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.transform(source, result);
        System.out.println("XML con las recetas generado");
	}
	
  }